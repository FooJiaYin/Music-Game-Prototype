﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class speed : MonoBehaviour{

    private Rigidbody rd;
    public int force = 5;
    bool active = false;
    public KeyCode key;
    GameObject ball;
 

    // Use this for initialization
    void Start()
    {
        rd = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update(){

        if (Input.GetKeyDown(key) && active)
        {
            scorescript.scorevalue += 1000;
            Debug.Log("Destroying "+ball.name+", score: "+scorescript.scorevalue);
            Destroy(ball);
          
        }
    }

     void OnTriggerEnter(Collider collider)
    {
        active = true;
        if (collider.gameObject.tag == "plane")
            ball = this.gameObject;
            Debug.Log(this.gameObject + " collid with " + collider.gameObject.name);
    }

    void OnTriggerExit(Collider collider)
    {
        active = false;    
    }
}