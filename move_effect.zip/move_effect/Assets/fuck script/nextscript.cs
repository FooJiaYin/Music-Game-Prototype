﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class nextscript : MonoBehaviour {

    public void ChangeScene(string fucks2)
    {
        Application.LoadLevel(fucks2);
    } 

}
